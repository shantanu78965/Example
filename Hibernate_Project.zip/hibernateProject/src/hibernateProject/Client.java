package hibernateProject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Student.class);
		
		SessionFactory factory =cfg.buildSessionFactory();
		Session session=factory.openSession();
		 Transaction transaction =session.beginTransaction();
		// Student student = new Student(103, "Mukesh", "Mumbai"); // insert method
		 Student student = session.load(Student.class, 103);   // to delete database 
		session.delete(student);  // delete method
		// session.save(student); 	// insert method
		transaction.commit();
		System.out.println(student);
	}

}
